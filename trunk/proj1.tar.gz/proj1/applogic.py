import sys
import os
import datetime

def run(query, cookie):
    return """\
		<H1>Hello world.</H1>
		This is a trivial web application.
		"""

